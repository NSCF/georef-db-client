<script>
	import { array } from './store.js'

	import TableRow from './TableRow.svelte'
	
	$array.push({name: 'mike', val: 1})
	$array.push({name: 'scotty', val: 2})
</script>

<table>
	<tr>
		{#each Object.keys($array[0]) as key}
			<th>{key}</th>
		{/each}
	</tr>
	{#each $array as item, index}
		<TableRow {index}/>
	{/each}
</table>

<p>
	<i>And this is a totally different table</i>
</p>
<table>
	{#each $array as item, index}
		<TableRow {index}/>
	{/each}
</table>