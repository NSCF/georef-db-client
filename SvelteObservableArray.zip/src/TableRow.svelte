<script>
	import { array } from './store.js'
	export let index
	const increment = _ => {
		$array[index].val++
	}
</script>
<tr on:click={increment}>
	{#each Object.keys($array[index]) as key}
		<td>{$array[index][key]}</td>
	{/each}
</tr>