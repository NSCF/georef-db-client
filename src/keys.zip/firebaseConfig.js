export const firebaseConfig = {
  apiKey: "AIzaSyBwK_DbeqcjfjRbqlZcrYnFYMn8GmbarHQ",
  authDomain: "georef-745b9.firebaseapp.com",
  databaseURL: "https://georef-745b9.firebaseio.com",
  projectId: "georef-745b9",
  storageBucket: "georef-745b9.appspot.com",
  messagingSenderId: "162606464079",
  appId: "1:162606464079:web:ed51bb48a5443b0795be3a"
};