const mapsAPIKey = 'AIzaSyBwK_DbeqcjfjRbqlZcrYnFYMn8GmbarHQ'

export {
  mapsAPIKey
}